const menu = document.getElementById("menu")
const nav = document.getElementById("nav")
console.log(nav)

menu.addEventListener("click", () => {
    nav.setAttribute("hidden", true);
    nav.style.width = 50;
    if (nav.getAttribute("hidden") == true) {
        nav.setAttribute("hidden", false)
    }
    
})

//   Search Button Funtionallity

document.getElementById("searchInput").addEventListener("keyup", function(event) {
    handleSearch();
    
    if (event.key === 'Enter') {
      // Call a function to handle the search
      handleSearch();
    }
  });

  
  
  function handleSearch() {
    // Get the search query from the input field
    var searchQuery = document.getElementById("searchInput").value.toLowerCase();
    
    // Get all video elements
    var videos = document.querySelectorAll(".video");
  
    // Loop through each video element and check if it contains the search query
    videos.forEach(function(video) {
      var videoTitle = video.querySelector(".video-details p").textContent.toLowerCase();
      if (videoTitle.includes(searchQuery)) {
        // If the video title contains the search query, show the video
        video.style.display = "block";
      } else {
        // If the video title does not contain the search query, hide the video
        video.style.display = "none";
      }
    });
  }
  

  window.onload = function() {
    handleSearch();
  };
  